package com.github.foodbox_project.api.service;

public interface IValidationService {

    void validatePagination(int start, int limit);
}

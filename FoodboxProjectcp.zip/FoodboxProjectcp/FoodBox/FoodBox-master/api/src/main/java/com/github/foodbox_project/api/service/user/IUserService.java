package com.github.foodbox_project.api.service.user;

import com.github.foodbox_project.api.service.IGenericService;
import com.github.foodbox_project.model.user.User;

public interface IUserService extends IGenericService<User, Long> {
}

package com.github.foodbox_project.dto.address;

import lombok.Data;

@Data
public class AddAddressDto {

    private String address;
    private Long cityId;
}

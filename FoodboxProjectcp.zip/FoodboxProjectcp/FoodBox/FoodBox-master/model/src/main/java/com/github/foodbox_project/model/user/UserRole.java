package com.github.foodbox_project.model.user;

/**
 * Created by earthofmarble on Nov, 2019
 */

public enum UserRole {

    ROLE_USER,
    ROLE_STAFF_MEMBER,
    ROLE_ADMIN

}

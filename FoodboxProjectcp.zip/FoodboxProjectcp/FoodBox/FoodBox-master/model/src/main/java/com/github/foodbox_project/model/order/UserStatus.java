package com.github.foodbox_project.model.order;

/**
 * Created by earthofmarble on Nov, 2019
 */

public enum UserStatus {

    TAKEN,
    AWAITING,
    IN_PROGRESS

}

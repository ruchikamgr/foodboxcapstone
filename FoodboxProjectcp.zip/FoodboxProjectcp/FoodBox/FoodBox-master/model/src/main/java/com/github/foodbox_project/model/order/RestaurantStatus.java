package com.github.foodbox_project.model.order;

/**
 * Created by earthofmarble on Nov, 2019
 */

public enum RestaurantStatus {

    NEW,
    IN_PROGRESS,
    DONE

}

package com.github.foodbox_project.model.user;

/**
 * Created by earthofmarble on Nov, 2019
 */

public enum  SentOption {

    PHONE,
    EMAIL

}

package com.github.foodbox_project.dal.address;

import com.github.foodbox_project.dal.GenericRepository;
import com.github.foodbox_project.model.address.Country;

public interface CountryRepository extends GenericRepository<Country, Long> {
}

package com.github.foodbox_project.dal.address;

import com.github.foodbox_project.dal.GenericRepository;
import com.github.foodbox_project.model.address.City;

public interface CityRepository extends GenericRepository<City, Long> {
}

package com.github.foodbox_project.dal.address;

import com.github.foodbox_project.dal.GenericRepository;
import com.github.foodbox_project.model.address.Address;

public interface AddressRepository extends GenericRepository<Address, Long> {
}
